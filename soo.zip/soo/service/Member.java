package developers.soo.service;

import javafx.scene.Parent;

public interface Member {
	public void setRoot(Parent root);
	public void MemInput();
	public void setCheckbox();
	public void setClose();
	
}
