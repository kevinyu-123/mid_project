package developers.soo.service;

import javafx.scene.Parent;

public interface PwdSearch {
	public void setRoot(Parent root);
	public void setPwd();
	public void setCombo();
	public void setClose();
	
}
