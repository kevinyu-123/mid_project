package developers.soo.service;

import dto.MemberDTO;
import javafx.scene.Parent;

public interface Mypage {
	public void setRoot(Parent root);
	public void setClose();
	public void setModify();
	public void setView();
}
